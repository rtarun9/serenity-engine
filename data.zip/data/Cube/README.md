# Cube
## Screenshot

![screenshot](screenshot/screenshot.jpg)

## Note
Contains modified base color texture obtained from https://kenney.nl/assets/prototype-textures

## License Information

Donated by Norbert Nopper for glTF testing.